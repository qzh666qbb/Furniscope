"""FurniScope FastAPI infrastructure package."""

from .app import create_app

__all__ = ["create_app"]
