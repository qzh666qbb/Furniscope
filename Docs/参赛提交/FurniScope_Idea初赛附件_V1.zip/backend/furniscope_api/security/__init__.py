"""Authentication security primitives."""
