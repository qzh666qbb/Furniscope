# FurniScope 跨境家具超级 AI 员工

## 项目概览

FurniScope 参加“赛道三：AI 市场洞察”。它面向缺少数字化市场研究团队的跨境家具制造商，将产品资料、企业制造约束、竞品商品和消费者评论连接起来，由一个超级 AI 员工自主完成市场研究、竞品分析、评论洞察、机会判断、产品建议和证据化报告。

代码仓库：https://github.com/qzh666qbb/Furniscope

## 业务闭环

1. 用户输入目标市场并提供产品、企业能力和授权市场数据。
2. AI 建立产品画像，检查数据质量并发现可比竞品。
3. AI 从评论中提取消费者需求、痛点、情绪与原文证据 Span。
4. 确定性程序计算价格、比例、竞争指标和六维机会评分。
5. AI 将机会与企业材料、工艺、成本、包装和认证能力进行适配。
6. 系统输出结论、置信度、工程建议、风险、待验证事项及证据索引。

默认自主执行；仅在关键事实冲突、样本不足、低置信度或高风险建议时触发 `user_confirmation`，通过 LangGraph Checkpoint 安全恢复。

## 技术架构

- 前端：React 19 + Vite。
- API：Python FastAPI，统一 Envelope、RS256 鉴权、租户上下文和持久化幂等。
- Agent：LangGraph，内部专业节点、并行 Map/Reduce、自动重试、降级、部分失败和断点恢复。
- AI：阿里云百炼 Model Router；视觉理解、文本推理、Embedding 与 Rerank 按任务路由。
- 数据：PostgreSQL 保存业务事实、证据、模型运行、任务状态和 Checkpoint 投影；Redis 保存运行锁和短期缓存；对象存储保存授权原始文件。
- 安全：密钥只从环境变量读取；用户数据按 `tenant_id` 隔离；不在日志中记录密码、Token、API Key 或评论全文。

## 当前实现进度

- PostgreSQL V3 完整 DDL、约束、索引和迁移方案已完成。
- LangGraph 主工作流、用户确认、Outbox、Checkpoint 恢复和节点幂等已完成。
- FastAPI 基础设施、认证、持久化幂等、产品、市场数据集及分析任务接口已完成。
- React 产品原型及关键页面视觉稿已具备。
- 附件包含《FurniScope 完整 UI 页面设计稿 V1》PDF，可直接查看端到端页面方案。
- 自动化测试覆盖 Agent、PostgreSQL 集成、API 基础设施、认证与幂等；当前开发记录显示最近一次全量测试 30 项通过、0 skipped。

## 演示数据声明

现阶段因合作企业数字化数据有限，Demo 中允许使用结构符合业务口径的合成家具市场数据。所有合成数据必须标记为 `demo_synthetic` 或 `demo_only`，不得宣称为真实平台统计或已验证商业结论。

## 评审建议阅读顺序

1. 压缩包根目录 `00_ATTACHMENT_MANIFEST.md`，查看逐目录内容清单；
2. 本说明；
3. PRD V2；
4. Mermaid V3 架构与流程图；
5. 页面原型 V3 与 UI 截图；
6. Agent 工作流 V2、API V3、数据库 V3；
7. 开发实现说明、核心代码和测试。
